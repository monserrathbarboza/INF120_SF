unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, UCadena, StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Aplicacion: TLabel;
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    procedure Button3Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    C:Cadena;
  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
  C:=Cadena.Create;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  C.Cargar(Edit1.Text);
  C.mayusculas;
  Edit2.Text := C.Mostrar;
end;

end.

