unit UCadena;

{$mode objfpc}{$H+}

interface

type
  Cadena = class
  private
    texto: string;
  public
    procedure Cargar(s: string);
    function Mostrar: string;

    procedure addChar(c: char);
    procedure insChar(p: integer; c: char);
    procedure elimChar(p: integer);
    procedure interChar(c: char);
    function cantChar: integer;
    function getChar(p: integer): char;
    function busqChar(c: char): integer;

    function cantPal: integer;
    procedure insPal(p: integer; palabra: string);
    procedure elimPal(p: integer);
    procedure cambPal(p: integer; palabra: string);
    function buscPal(palabra: string): integer;
    procedure addPal(palabra: string);

    procedure invertir;
    procedure rotar;
    procedure mayusculas;
    procedure minusculas;
    procedure Titulo;
  end;

implementation

procedure Cadena.Cargar(s: string);
begin
  texto := s;
end;

function Cadena.Mostrar: string;
begin
  Mostrar := texto;
end;

//P
procedure Cadena.addChar(c: char);
begin
  texto := texto + c;
end;

//P
procedure Cadena.insChar(p: integer; c: char);
var
  i: integer;
begin
  if (p >= 1) and (p <= Length(texto) + 1) then
  begin
    texto := texto + ' ';

    for i := Length(texto) downto p + 1 do
      texto[i] := texto[i - 1];

    texto[p] := c;
  end;
end;

//P
procedure Cadena.elimChar(p: integer);
var
  i: integer;
begin
  if (p >= 1) and (p <= Length(texto)) then
  begin
    for i := p to Length(texto) - 1 do
      texto[i] := texto[i + 1];

    Delete(texto, Length(texto), 1);
  end;
end;

procedure Cadena.interChar(c: char);
var
  i: integer;
  s: string;
begin
  s := '';

  for i := 1 to Length(texto) do
  begin
    s := s + texto[i];

    if i < Length(texto) then
      s := s + c;
  end;

  texto := s;
end;

function Cadena.cantChar: integer;
begin
  cantChar := Length(texto);
end;

function Cadena.getChar(p: integer): char;
begin
  getChar := #0;

  if (p >= 1) and (p <= Length(texto)) then
    getChar := texto[p];
end;

function Cadena.busqChar(c: char): integer;
var
  i: integer;
begin
  busqChar := 0;
  i := 1;

  while (i <= Length(texto)) and (busqChar = 0) do
  begin
    if texto[i] = c then
      busqChar := i;

    i := i + 1;
  end;
end;

function Cadena.cantPal: integer;
var
  i: integer;
  dentro: boolean;
begin
  cantPal := 0;
  dentro := false;

  for i := 1 to Length(texto) do
  begin
    if texto[i] <> ' ' then
    begin
      if not dentro then
      begin
        cantPal := cantPal + 1;
        dentro := true;
      end;
    end
    else
      dentro := false;
  end;
end;

procedure Cadena.insPal(p: integer; palabra: string);
var
  i: integer;
  s: string;
begin
  if (p >= 1) and (p <= Length(texto) + 1) then
  begin
    s := '';

    for i := 1 to p - 1 do
      s := s + texto[i];

    s := s + palabra + ' ';

    for i := p to Length(texto) do
      s := s + texto[i];

    texto := s;
  end;
end;

procedure Cadena.elimPal(p: integer);
var
  i, inicio, fin, num: integer;
  s: string;
begin
  i := 1;
  num := 0;
  s := '';

  while i <= Length(texto) do
  begin
    while (i <= Length(texto)) and (texto[i] = ' ') do
    begin
      s := s + texto[i];
      i := i + 1;
    end;

    inicio := i;

    while (i <= Length(texto)) and (texto[i] <> ' ') do
      i := i + 1;

    fin := i - 1;

    if inicio <= fin then
    begin
      num := num + 1;

      if num <> p then
        for i := inicio to fin do
          s := s + texto[i];
    end;
  end;

  texto := s;
end;

procedure Cadena.cambPal(p: integer; palabra: string);
var
  i, inicio, fin, num: integer;
  s: string;
begin
  i := 1;
  num := 0;
  s := '';

  while i <= Length(texto) do
  begin
    if texto[i] = ' ' then
    begin
      s := s + texto[i];
      i := i + 1;
    end
    else
    begin
      inicio := i;

      while (i <= Length(texto)) and (texto[i] <> ' ') do
        i := i + 1;

      fin := i - 1;
      num := num + 1;

      if num = p then
        s := s + palabra
      else
        for fin := inicio to i - 1 do
          s := s + texto[fin];
    end;
  end;

  texto := s;
end;

function Cadena.buscPal(palabra: string): integer;
var
  i, j, num, inicio: integer;
  igual: boolean;
begin
  buscPal := 0;
  i := 1;
  num := 0;

  while i <= Length(texto) do
  begin
    while (i <= Length(texto)) and (texto[i] = ' ') do
      i := i + 1;

    inicio := i;

    while (i <= Length(texto)) and (texto[i] <> ' ') do
      i := i + 1;

    if inicio < i then
    begin
      num := num + 1;
      igual := i - inicio = Length(palabra);

      if igual then
        for j := 1 to Length(palabra) do
          if texto[inicio + j - 1] <> palabra[j] then
            igual := false;

      if igual and (buscPal = 0) then
        buscPal := num;
    end;
  end;
end;

procedure Cadena.addPal(palabra: string);
begin
  if texto <> '' then
    texto := texto + ' ';

  texto := texto + palabra;
end;

procedure Cadena.invertir;
var
  i: integer;
  s: string;
begin
  s := '';

  for i := Length(texto) downto 1 do
    s := s + texto[i];

  texto := s;
end;

procedure Cadena.rotar;
var
  i: integer;
  c: char;
begin
  if Length(texto) > 1 then
  begin
    c := texto[Length(texto)];

    for i := Length(texto) downto 2 do
      texto[i] := texto[i - 1];

    texto[1] := c;
  end;
end;

procedure Cadena.mayusculas;
var
  i: integer;
begin
  for i := 1 to Length(texto) do
    texto[i] := UpCase(texto[i]);
end;

procedure Cadena.minusculas;
var
  i: integer;
begin
  for i := 1 to Length(texto) do
    if (texto[i] >= 'A') and (texto[i] <= 'Z') then
      texto[i] := Chr(Ord(texto[i]) + 32);
end;

procedure Cadena.Titulo;
var
  i: integer;
  nueva: boolean;
begin
  nueva := true;

  for i := 1 to Length(texto) do
  begin
    if texto[i] = ' ' then
      nueva := true
    else
    begin
      if nueva then
        texto[i] := UpCase(texto[i])
      else if (texto[i] >= 'A') and (texto[i] <= 'Z') then
        texto[i] := Chr(Ord(texto[i]) + 32);

      nueva := false;
    end;
  end;
end;

end.

