unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, UCadena, StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Aplicacion: TLabel;
    Button1: TButton;
    Button10: TButton;
    Button11: TButton;
    Button12: TButton;
    Button13: TButton;
    Button14: TButton;
    Button15: TButton;
    Button16: TButton;
    Button17: TButton;
    Button18: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    Button9: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    procedure Button10Click(Sender: TObject);
    procedure Button11Click(Sender: TObject);
    procedure Button12Click(Sender: TObject);
    procedure Button13Click(Sender: TObject);
    procedure Button14Click(Sender: TObject);
    procedure Button15Click(Sender: TObject);
    procedure Button16Click(Sender: TObject);
    procedure Button17Click(Sender: TObject);
    procedure Button18Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    C:Cadena;
  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
  C:=Cadena.Create;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  C.Cargar(Edit1.Text);
  C.mayusculas;
  Edit2.Text := C.Mostrar;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  C.Cargar(Edit1.Text);
  C.invertir;
  Edit2.Text := C.Mostrar;
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  C.Cargar(Edit1.Text);
  Edit2.Text := IntToStr(C.cantChar);
end;

procedure TForm1.Button13Click(Sender: TObject);
begin
  if Edit2.Text <> '' then
begin
  C.Cargar(Edit1.Text);
  Edit3.Text := IntToStr(C.busqChar(Edit2.Text[1]));
end;
end;

procedure TForm1.Button14Click(Sender: TObject);
begin
  if (Edit2.Text <> '') and (Edit3.Text <> '') then
begin
  C.Cargar(Edit1.Text);
  C.insPal(StrToInt(Edit3.Text), Edit2.Text);
  Edit1.Text := C.Mostrar;
end;
end;

procedure TForm1.Button15Click(Sender: TObject);
begin
 if Edit2.Text <> '' then
begin
  C.Cargar(Edit1.Text);
  C.elimPal(StrToInt(Edit2.Text));
  Edit1.Text := C.Mostrar;
end;
end;

procedure TForm1.Button16Click(Sender: TObject);
begin
  if (Edit2.Text <> '') and (Edit3.Text <> '') then
begin
  C.Cargar(Edit1.Text);
  C.cambPal(StrToInt(Edit3.Text), Edit2.Text);
  Edit1.Text := C.Mostrar;
end;
end;

procedure TForm1.Button17Click(Sender: TObject);
begin
  if Edit2.Text <> '' then
begin
  C.Cargar(Edit1.Text);
  Edit3.Text := IntToStr(C.buscPal(Edit2.Text));
end;
end;

procedure TForm1.Button18Click(Sender: TObject);
begin
  if Edit2.Text <> '' then
begin
  C.Cargar(Edit1.Text);
  C.addPal(Edit2.Text);
  Edit1.Text := C.Mostrar;
end;
end;

procedure TForm1.Button10Click(Sender: TObject);
begin
  if Edit2.Text <> '' then
begin
  C.Cargar(Edit1.Text);
  C.elimChar(StrToInt(Edit2.Text));
  Edit1.Text := C.Mostrar;
end;
end;

procedure TForm1.Button11Click(Sender: TObject);
begin
  if Edit2.Text <> '' then
begin
  C.Cargar(Edit1.Text);
  Edit3.Text := C.getChar(StrToInt(Edit2.Text));
end;
end;

procedure TForm1.Button12Click(Sender: TObject);
begin
  if Edit2.Text <> '' then
begin
  C.Cargar(Edit1.Text);
  C.interChar(Edit2.Text[1]);
  Edit1.Text := C.Mostrar;
end;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
 C.Cargar(Edit1.Text);
 C.minusculas;
 Edit2.Text := C.Mostrar;
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
  C.Cargar(Edit1.Text);
  Edit2.Text := IntToStr(C.cantPal);
end;

procedure TForm1.Button6Click(Sender: TObject);
begin
 C.Cargar(Edit1.Text);
 C.rotar;
 Edit2.Text := C.Mostrar;
end;

procedure TForm1.Button7Click(Sender: TObject);
begin
  C.Cargar(Edit1.Text);
  C.Titulo;
  Edit2.Text := C.Mostrar;
end;

procedure TForm1.Button8Click(Sender: TObject);
begin
   if Edit2.Text <> '' then
   begin
     C.Cargar(Edit1.Text);
    C.addChar(Edit2.Text[1]);
     Edit1.Text := C.Mostrar;

   end;
end;

procedure TForm1.Button9Click(Sender: TObject);
begin
 if (Edit2.Text <> '') and (Edit3.Text <> '') then
 begin
  C.Cargar(Edit1.Text);
  C.insChar(StrToInt(Edit3.Text), Edit2.Text[1]);
  Edit1.Text := C.Mostrar;
 end;
end;
end.

