unit UVector;

{$mode objfpc}{$H+}

interface

uses
  SysUtils;

type
  TVector = class
  private
    V: array[1..100] of Integer;
    n: Integer;
  public
    procedure Cargar(s: string);
    procedure Ordenar;
    function Mostrar: string;
    function CantCortes: Integer;
  end;

implementation

procedure TVector.Cargar(s: string);
var
  i, num: Integer;
  palabra: string;
begin
  n := 0;
  palabra := '';

  for i := 1 to Length(s) do
  begin
    if s[i] <> ',' then
      palabra := palabra + s[i]
    else
    begin
      if palabra <> '' then
      begin
        num := StrToInt(Trim(palabra));
        n := n + 1;
        V[n] := num;
        palabra := '';
      end;
    end;
  end;

  if palabra <> '' then
  begin
    num := StrToInt(Trim(palabra));
    n := n + 1;
    V[n] := num;
  end;
end;

procedure TVector.Ordenar;
var
  i, j, aux: Integer;
begin
  for i := 1 to n - 1 do
    for j := i + 1 to n do
      if V[i] > V[j] then
      begin
        aux := V[i];
        V[i] := V[j];
        V[j] := aux;
      end;
end;

function TVector.Mostrar: string;
var
  i: Integer;
begin
  Result := '[';
  for i := 1 to n do
  begin
    Result := Result + IntToStr(V[i]);
    if i < n then
      Result := Result + ', ';
  end;
  Result := Result + ']';
end;

function TVector.CantCortes: Integer;
var
  i: Integer;
begin
  Result := 0;
  for i := 2 to n do
    if V[i] <> V[i - 1] then
      Result := Result + 1;
end;

end.
