unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms,UVector, Controls, Graphics, Dialogs, StdCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Label1: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    V:TVector;
  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.Button1Click(Sender: TObject);
begin
  V.Cargar(Edit1.Text);
  V.Ordenar;
  Edit3.Text:=V.Mostrar;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  V.Cargar(Edit1.Text);
  V.Ordenar;
  Edit3.Text:=Inttostr(V.CantCortes);
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  V.Cargar(Edit1.text);
  V.Ordenar;
  Edit3.text:=V.CantElementos;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
  V.Cargar(edit1.text);
  Edit3.text:=V.SepararParesImpares;
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
  V.Cargar(edit1.text);
  edit3.text:=V.Intercalar(Edit2.Text);
end;

procedure TForm1.Button6Click(Sender: TObject);
begin
  V.Cargar(edit1.text);
  V.Ordenar;
  edit3.text:=V.Purgar;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  V:=TVector.Create;
end;

end.

