unit UVector;

{$mode objfpc}{$H+}

interface

uses
  SysUtils;

type
  TVector = class
  private
    V: array[1..100] of Integer;
    n: Integer;
  public
    procedure Cargar(s: string);
    procedure Ordenar;
    function Mostrar: string;
    function CantCortes: Integer;
    function CantElementos: string;
    function SepararParesImpares: string;
    function Intercalar(s: string): string;
    function Purgar: string;
  end;

implementation

procedure TVector.Cargar(s: string);
var
  i, num: Integer;
  palabra: string;
begin
  n := 0;
  palabra := '';

  for i := 1 to Length(s) do
  begin
    if s[i] <> ',' then
      palabra := palabra + s[i]
    else
    begin
      if palabra <> '' then
      begin
        num := StrToInt(Trim(palabra));
        n := n + 1;
        V[n] := num;
        palabra := '';
      end;
    end;
  end;

  if palabra <> '' then
  begin
    num := StrToInt(Trim(palabra));
    n := n + 1;
    V[n] := num;
  end;
end;

procedure TVector.Ordenar;
var
  i, j, aux: Integer;
begin
  for i := 1 to n - 1 do
    for j := i + 1 to n do
      if V[i] > V[j] then
      begin
        aux := V[i];
        V[i] := V[j];
        V[j] := aux;
      end;
end;

function TVector.Mostrar: string;
var
  i: Integer;
begin
  Result := '[';
  for i := 1 to n do
  begin
    Result := Result + IntToStr(V[i]);
    if i < n then
      Result := Result + ', ';
  end;
  Result := Result + ']';
end;

function TVector.CantCortes: Integer;
var
  i: Integer;
begin
  Result := 0;
  for i := 2 to n do
    if V[i] <> V[i - 1] then
      Result := Result + 1;
end;

function TVector.CantElementos: string;
var
  i, cant: Integer;
begin
  Result := '';
  i := 1;

  while i <= n do
  begin
    cant := 1;

    while (i + cant <= n) and
          (V[i] = V[i + cant]) do
      cant := cant + 1;

    Result := Result + IntToStr(cant) + ' ';
    i := i + cant;
  end;
end;

function TVector.SepararParesImpares: string;
var
  i: Integer;
  pares, impares: string;
begin
  pares := '';
  impares := '';

  for i := 1 to n do
  begin
    if V[i] mod 2 = 0 then
      pares := pares + IntToStr(V[i]) + ' '
    else
      impares := impares + IntToStr(V[i]) + ' ';
  end;

  Result := 'Pares: ' + pares +
            ' | Impares: ' + impares;
end;

function TVector.Intercalar(s: string): string;
var
  B: TVector;
  i, mayor: Integer;
begin
  B := TVector.Create;
  B.Cargar(s);

  Result := '';
  mayor := n;

  if B.n > mayor then
    mayor := B.n;

  for i := 1 to mayor do
  begin
    if i <= n then
      Result := Result + IntToStr(V[i]) + ' ';

    if i <= B.n then
      Result := Result + IntToStr(B.V[i]) + ' ';
  end;

  B.Free;
end;

function TVector.Purgar: string;
var
  i, j: Integer;
begin
  Result := '';

  for i := 1 to n do
  begin
    if (i = 1) or (V[i] <> V[i - 1]) then
      Result := Result + IntToStr(V[i]) + ' ';
  end;
end;
end.
