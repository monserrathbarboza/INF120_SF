
unit fmatriz;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs,
  umatriz, StdCtrls, Grids;

type
  { TForm1 }

  TForm1 = class(TForm)
    B1: TButton;
    B2: TButton;
    B3: TButton;
    B4: TButton;
    B5: TButton;
    B6: TButton;
    Button1: TButton;
    Button10: TButton;
    Button11: TButton;
    Button12: TButton;
    Button13: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    Button9: TButton;
    Fil: TEdit;
    Col: TEdit;
    Ele: TEdit;
    Filas2: TEdit;
    Columnas2: TEdit;
    Label1: TLabel;
    SG: TStringGrid;
    SG2: TStringGrid;

    procedure B1Click(Sender: TObject);
    procedure B2Click(Sender: TObject);
    procedure B3Click(Sender: TObject);
    procedure B4Click(Sender: TObject);
    procedure B5Click(Sender: TObject);
    procedure B6Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure Button10Click(Sender: TObject);
    procedure Button11Click(Sender: TObject);
    procedure Button12Click(Sender: TObject);
    procedure Button13Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Label1Click(Sender: TObject);

  private
    M: matriz;
    M2: matriz;

    procedure updateSG;
    procedure cargarM2;
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

procedure TForm1.Label1Click(Sender: TObject);
begin
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  M := nil;
  M2 := nil;

  SG.FixedRows := 0;
  SG.FixedCols := 0;
  SG.Options := SG.Options + [goEditing];

  SG2.FixedRows := 0;
  SG2.FixedCols := 0;
  SG2.Options := SG2.Options + [goEditing];
end;

procedure TForm1.updateSG;
var
  f, c: integer;
begin
  if M = nil then
    Exit;

  if M.getfils() < 1 then
    Exit;

  if M.getcol() < 1 then
    Exit;

  SG.RowCount := M.getfils();
  SG.ColCount := M.getcol();

  for f := 1 to M.getfils() do
    for c := 1 to M.getcol() do
      SG.Cells[c-1,f-1] := FloatToStr(M.getelem(f,c));
end;

procedure TForm1.cargarM2;
var
  i, j, f, c: integer;
  valor: double;
begin
  if (Trim(Filas2.Text) = '') or (Trim(Columnas2.Text) = '') then
    raise Exception.Create('Ingrese las dimensiones de la segunda matriz');

  f := StrToInt(Filas2.Text);
  c := StrToInt(Columnas2.Text);

  if (f < 1) or (f > MAX_FIL) or
     (c < 1) or (c > MAX_COL) then
    raise Exception.Create('Dimensiones incorrectas');

  if (SG2.RowCount <> f) or (SG2.ColCount <> c) then
    raise Exception.Create('Primero configure las dimensiones de SG2');

  M2 := matriz.crear();
  M2.setfils(f);
  M2.setcol(c);

  for i := 1 to f do
    for j := 1 to c do
    begin
      if Trim(SG2.Cells[j-1,i-1]) = '' then
        raise Exception.Create('Complete todos los valores de SG2');

      if not TryStrToFloat(SG2.Cells[j-1,i-1], valor) then
        raise Exception.Create('Hay un valor incorrecto en SG2');

      M2.setelem(i,j,valor);
    end;
end;

procedure TForm1.B1Click(Sender: TObject);
begin
  M := matriz.crear();
  M2 := matriz.crear();

  ShowMessage('Matrices creadas');
end;

procedure TForm1.B2Click(Sender: TObject);
var
  f: integer;
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  if not TryStrToInt(Fil.Text,f) or (f < 1) or (f > MAX_FIL) then
  begin
    ShowMessage('Ingrese una cantidad de filas válida');
    Exit;
  end;

  M.setfils(f);
  updateSG;
end;

procedure TForm1.B3Click(Sender: TObject);
var
  c: integer;
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  if not TryStrToInt(Col.Text,c) or (c < 1) or (c > MAX_COL) then
  begin
    ShowMessage('Ingrese una cantidad de columnas válida');
    Exit;
  end;

  M.setcol(c);
  updateSG;
end;

procedure TForm1.B4Click(Sender: TObject);
var
  f, c: integer;
  e: double;
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  if not TryStrToInt(Fil.Text,f) or
     not TryStrToInt(Col.Text,c) or
     not TryStrToFloat(Ele.Text,e) then
  begin
    ShowMessage('Ingrese fila, columna y elemento válidos');
    Exit;
  end;

  if (f < 1) or (f > M.getfils()) or
     (c < 1) or (c > M.getcol()) then
  begin
    ShowMessage('La posición está fuera de la matriz');
    Exit;
  end;

  M.setelem(f,c,e);
  updateSG;
end;

procedure TForm1.B5Click(Sender: TObject);
begin
  Close;
end;

procedure TForm1.B6Click(Sender: TObject);
var
    fi, co: integer;
    valor: double;
  begin
    valor := StrToFloat(Ele.Text);

    if M.buscar(valor, fi, co) then
      ShowMessage('Encontrado en fila: ' + IntToStr(fi) +
                  ' columna: ' + IntToStr(co))
    else
      ShowMessage('No encontrado');
  end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  if M.triangularSuperior() then
    ShowMessage('Es triangular superior')
  else
    ShowMessage('No es triangular superior');
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  if not M.escuadrada() then
  begin
    ShowMessage('La matriz debe ser cuadrada');
    Exit;
  end;

  ShowMessage('Suma diagonal principal: ' +
    FloatToStr(M.sumadiaprin()));
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  if not M.escuadrada() then
  begin
    ShowMessage('La matriz debe ser cuadrada');
    Exit;
  end;

  ShowMessage('Suma diagonal secundaria: ' +
    FloatToStr(M.sumadiasecu()));
end;

procedure TForm1.Button4Click(Sender: TObject);
var
  R: matriz;
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la primera matriz');
    Exit;
  end;

  try
    cargarM2;
    R := M.sumar(M2);

    if R = nil then
      ShowMessage('Las matrices deben tener las mismas dimensiones')
    else
    begin
      M := R;
      updateSG;
      ShowMessage('Suma realizada');
    end;
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

procedure TForm1.Button5Click(Sender: TObject);
var
  R: matriz;
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la primera matriz');
    Exit;
  end;

  try
    cargarM2;
    R := M.restar(M2);

    if R = nil then
      ShowMessage('Las matrices deben tener las mismas dimensiones')
    else
    begin
      M := R;
      updateSG;
      ShowMessage('Resta realizada');
    end;
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

procedure TForm1.Button6Click(Sender: TObject);
var
  R: matriz;
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la primera matriz');
    Exit;
  end;

  try
    cargarM2;
    R := M.multiplicar(M2);

    if R = nil then
      ShowMessage('Las columnas de la primera matriz deben ser iguales a las filas de la segunda')
    else
    begin
      M := R;
      updateSG;
      ShowMessage('Multiplicación realizada');
    end;
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

procedure TForm1.Button7Click(Sender: TObject);
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  M.invertir();
  updateSG;

  ShowMessage('Matriz invertida');
end;

procedure TForm1.Button8Click(Sender: TObject);
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  if not M.escuadrada() then
  begin
    ShowMessage('La matriz debe ser cuadrada');
    Exit;
  end;

  ShowMessage('Determinante: ' + FloatToStr(M.determinante()));
end;

procedure TForm1.Button9Click(Sender: TObject);
var
  R: matriz;
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  R := M.transpuesta();

  if R <> nil then
  begin
    M := R;
    updateSG;
    ShowMessage('Matriz transpuesta');
  end;
end;

procedure TForm1.Button10Click(Sender: TObject);
var
  R: matriz;
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  if not M.escuadrada() then
  begin
    ShowMessage('La matriz debe ser cuadrada');
    Exit;
  end;

  R := M.inversa();

  if R <> nil then
  begin
    M := R;
    updateSG;
    ShowMessage('Matriz inversa calculada');
  end
  else
    ShowMessage('La matriz no tiene inversa');
end;

procedure TForm1.Button11Click(Sender: TObject);
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  if M.triangularInferior() then
    ShowMessage('Es triangular inferior')
  else
    ShowMessage('No es triangular inferior');
end;

procedure TForm1.Button12Click(Sender: TObject);
begin
  if M = nil then
  begin
    ShowMessage('Primero cree la matriz');
    Exit;
  end;

  M.ordenar();
  updateSG;

  ShowMessage('Matriz ordenada');
end;

procedure TForm1.Button13Click(Sender: TObject);
var
  f, c: integer;
begin
  if not TryStrToInt(Filas2.Text,f) or
     not TryStrToInt(Columnas2.Text,c) then
  begin
    ShowMessage('Ingrese dimensiones válidas');
    Exit;
  end;

  if (f < 1) or (f > MAX_FIL) or
     (c < 1) or (c > MAX_COL) then
  begin
    ShowMessage('Dimensiones incorrectas');
    Exit;
  end;

  SG2.RowCount := f;
  SG2.ColCount := c;

  ShowMessage('Dimensiones de segunda matriz configuradas');
end;

end.

