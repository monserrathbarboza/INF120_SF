
unit umatriz;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Dialogs;

const
  MAX_FIL = 1000;
  MAX_COL = 1000;

type
  matriz = class
  private
    elem: array[1..MAX_FIL, 1..MAX_COL] of double;
    fils, cols: integer;

  public
    constructor crear();

    procedure setfils(f: integer);
    function getfils(): integer;

    procedure setcol(c: integer);
    function getcol(): integer;

    procedure setelem(f, c: integer; ele: double);
    function getelem(f, c: integer): double;

    function buscar(valor: double; var fi, co: integer): boolean;

    procedure ordenar();

    function escuadrada(): boolean;
    function sumadiaprin(): double;
    function sumadiasecu(): double;

    function triangularInferior(): boolean;
    function triangularSuperior(): boolean;

    function sumar(B: matriz): matriz;
    function restar(B: matriz): matriz;
    function multiplicar(B: matriz): matriz;

    procedure invertir();

    function determinante(): double;
    function transpuesta(): matriz;
    function inversa(): matriz;
  end;

implementation

constructor matriz.crear();
var
  f, c: integer;
begin
  fils := 0;
  cols := 0;

  for f := 1 to MAX_FIL do
    for c := 1 to MAX_COL do
      elem[f,c] := 0;
end;

procedure matriz.setfils(f: integer);
begin
  if (f >= 0) and (f <= MAX_FIL) then
    fils := f;
end;

function matriz.getfils(): integer;
begin
  result := fils;
end;

procedure matriz.setcol(c: integer);
begin
  if (c >= 0) and (c <= MAX_COL) then
    cols := c;
end;

function matriz.getcol(): integer;
begin
  result := cols;
end;

procedure matriz.setelem(f, c: integer; ele: double);
begin
  if (f >= 1) and (f <= fils) and
     (c >= 1) and (c <= cols) then
    elem[f,c] := ele;
end;

function matriz.getelem(f, c: integer): double;
begin
  result := 0;

  if (f >= 1) and (f <= fils) and
     (c >= 1) and (c <= cols) then
    result := elem[f,c];
end;

function matriz.buscar(valor: double; var fi, co: integer): boolean;
var
  f, c: integer;
begin
  result := false;
  fi := 0;
  co := 0;

  for f := 1 to fils do
    for c := 1 to cols do
      if elem[f,c] = valor then
      begin
        fi := f;
        co := c;
        result := true;
        exit;
      end;
end;

procedure matriz.ordenar();
var
  f, c, i, j: integer;
  aux: double;
begin
  for f := 1 to fils do
    for c := 1 to cols do
      for i := f to fils do
        for j := 1 to cols do
        begin
          if (i = f) and (j <= c) then
            continue;

          if elem[f,c] > elem[i,j] then
          begin
            aux := elem[f,c];
            elem[f,c] := elem[i,j];
            elem[i,j] := aux;
          end;
        end;
end;

function matriz.escuadrada(): boolean;
begin
  result := fils = cols;
end;

function matriz.sumadiaprin(): double;
var
  i: integer;
begin
  result := 0;

  if escuadrada() then
    for i := 1 to fils do
      result := result + elem[i,i];
end;

function matriz.sumadiasecu(): double;
var
  i: integer;
begin
  result := 0;

  if escuadrada() then
    for i := 1 to fils do
      result := result + elem[i,cols-i+1];
end;

function matriz.triangularInferior(): boolean;
var
  f, c: integer;
begin
  result := false;

  if not escuadrada() then
    exit;

  result := true;

  for f := 1 to fils do
    for c := f+1 to cols do
      if elem[f,c] <> 0 then
      begin
        result := false;
        exit;
      end;
end;

function matriz.triangularSuperior(): boolean;
var
  f, c: integer;
begin
  result := false;

  if not escuadrada() then
    exit;

  result := true;

  for f := 2 to fils do
    for c := 1 to f-1 do
      if elem[f,c] <> 0 then
      begin
        result := false;
        exit;
      end;
end;

function matriz.sumar(B: matriz): matriz;
var
  R: matriz;
  f, c: integer;
begin
  result := nil;

  if (B = nil) then
    exit;

  if (fils <> B.getfils()) or (cols <> B.getcol()) then
    exit;

  R := matriz.crear();
  R.setfils(fils);
  R.setcol(cols);

  for f := 1 to fils do
    for c := 1 to cols do
      R.setelem(f,c,elem[f,c] + B.getelem(f,c));

  result := R;
end;

function matriz.restar(B: matriz): matriz;
var
  R: matriz;
  f, c: integer;
begin
  result := nil;

  if (B = nil) then
    exit;

  if (fils <> B.getfils()) or (cols <> B.getcol()) then
    exit;

  R := matriz.crear();
  R.setfils(fils);
  R.setcol(cols);

  for f := 1 to fils do
    for c := 1 to cols do
      R.setelem(f,c,elem[f,c] - B.getelem(f,c));

  result := R;
end;

function matriz.multiplicar(B: matriz): matriz;
var
  R: matriz;
  f, c, k: integer;
  suma: double;
begin
  result := nil;

  if B = nil then
    exit;

  if cols <> B.getfils() then
    exit;

  R := matriz.crear();
  R.setfils(fils);
  R.setcol(B.getcol());

  for f := 1 to fils do
    for c := 1 to B.getcol() do
    begin
      suma := 0;

      for k := 1 to cols do
        suma := suma + elem[f,k] * B.getelem(k,c);

      R.setelem(f,c,suma);
    end;

  result := R;
end;

procedure matriz.invertir();
var
  f, c, total, pos1, pos2: integer;
  aux: double;
begin
  total := fils * cols;

  for f := 1 to total div 2 do
  begin
    pos1 := f;
    pos2 := total - f + 1;

    aux := elem[(pos1-1) div cols + 1, (pos1-1) mod cols + 1];

    elem[(pos1-1) div cols + 1, (pos1-1) mod cols + 1] :=
      elem[(pos2-1) div cols + 1, (pos2-1) mod cols + 1];

    elem[(pos2-1) div cols + 1, (pos2-1) mod cols + 1] := aux;
  end;
end;

function matriz.determinante(): double;
var
  a: array[1..MAX_FIL,1..MAX_COL] of double;
  f, c, k: integer;
  pivote, factor, aux: double;
begin
  result := 0;

  if (not escuadrada()) or (fils = 0) then
    exit;

  for f := 1 to fils do
    for c := 1 to cols do
      a[f,c] := elem[f,c];

  result := 1;

  for k := 1 to fils do
  begin
    if a[k,k] = 0 then
    begin
      f := k + 1;

      while (f <= fils) and (a[f,k] = 0) do
        f := f + 1;

      if f > fils then
      begin
        result := 0;
        exit;
      end;

      for c := 1 to cols do
      begin
        aux := a[k,c];
        a[k,c] := a[f,c];
        a[f,c] := aux;
      end;

      result := -result;
    end;

    pivote := a[k,k];
    result := result * pivote;

    for f := k+1 to fils do
    begin
      factor := a[f,k] / pivote;

      for c := k to cols do
        a[f,c] := a[f,c] - factor * a[k,c];
    end;
  end;
end;

function matriz.transpuesta(): matriz;
var
  R: matriz;
  f, c: integer;
begin
  result := nil;

  R := matriz.crear();
  R.setfils(cols);
  R.setcol(fils);

  for f := 1 to fils do
    for c := 1 to cols do
      R.setelem(c,f,elem[f,c]);

  result := R;
end;

function matriz.inversa(): matriz;
var
  a: array[1..MAX_FIL,1..2*MAX_COL] of double;
  f, c, k: integer;
  pivote, aux, factor: double;
  R: matriz;
begin
  result := nil;

  if (not escuadrada()) or (fils = 0) then
    exit;

  for f := 1 to fils do
    for c := 1 to cols do
    begin
      a[f,c] := elem[f,c];

      if f = c then
        a[f,c+cols] := 1
      else
        a[f,c+cols] := 0;
    end;

  for k := 1 to fils do
  begin
    if a[k,k] = 0 then
    begin
      f := k + 1;

      while (f <= fils) and (a[f,k] = 0) do
        f := f + 1;

      if f > fils then
        exit;

      for c := 1 to 2*cols do
      begin
        aux := a[k,c];
        a[k,c] := a[f,c];
        a[f,c] := aux;
      end;
    end;

    pivote := a[k,k];

    if pivote = 0 then
      exit;

    for c := 1 to 2*cols do
      a[k,c] := a[k,c] / pivote;

    for f := 1 to fils do
      if f <> k then
      begin
        factor := a[f,k];

        for c := 1 to 2*cols do
          a[f,c] := a[f,c] - factor * a[k,c];
      end;
  end;

  R := matriz.crear();
  R.setfils(fils);
  R.setcol(cols);

  for f := 1 to fils do
    for c := 1 to cols do
      R.setelem(f,c,a[f,c+cols]);

  result := R;
end;

end.

